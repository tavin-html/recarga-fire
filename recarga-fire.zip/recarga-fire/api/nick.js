// Consulta o nick de um jogador de Free Fire pelo ID.
//
// A Garena não tem API pública para isso, então esta função chama o serviço de
// consulta que VOCÊ escolher. Tudo é configurado por variáveis de ambiente na
// Vercel (veja o README.md). Sem configurar, o site continua funcionando e
// apenas avisa que não foi possível verificar o nick.
//
// Variáveis:
//   NICK_API_URL         (obrigatória) URL do serviço. Use {id} onde vai o ID
//                        e, se precisar, {region} onde vai a região.
//                        Ex.: https://meu-servico.exemplo/player?uid={id}&region={region}
//   NICK_API_REGION      região enviada em {region} (padrão: br)
//   NICK_API_KEY         chave/token do serviço, se ele exigir
//   NICK_API_KEY_HEADER  nome do header da chave (padrão: x-api-key).
//                        Se o serviço usa "Authorization: Bearer ...", use
//                        NICK_API_KEY_HEADER=Authorization e coloque em
//                        NICK_API_KEY o valor completo: Bearer SEU_TOKEN

var NAME_KEYS = ['nickname', 'nick', 'name', 'player_name', 'playerName', 'username'];

// Procura o nick em qualquer lugar do JSON (até 4 níveis de profundidade).
function findNick(obj, depth) {
  if (!obj || typeof obj !== 'object' || depth > 4) return '';
  var i;
  for (i = 0; i < NAME_KEYS.length; i++) {
    var v = obj[NAME_KEYS[i]];
    if (typeof v === 'string' && v.trim()) return v;
  }
  var keys = Object.keys(obj);
  for (i = 0; i < keys.length; i++) {
    var inner = obj[keys[i]];
    if (inner && typeof inner === 'object') {
      var found = findNick(inner, depth + 1);
      if (found) return found;
    }
  }
  return '';
}

function clean(name) {
  // remove caracteres de controle e limita o tamanho
  return String(name).replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 40);
}

module.exports = async function handler(req, res) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');

  var id = String((req.query && req.query.id) || '').trim();
  if (!/^\d{6,12}$/.test(id)) {
    return res.status(400).json({ ok: false, error: 'invalid_id' });
  }

  var tpl = process.env.NICK_API_URL;
  if (!tpl) {
    return res.status(503).json({ ok: false, error: 'not_configured' });
  }

  var region = process.env.NICK_API_REGION || 'br';
  var url = tpl
    .split('{id}').join(encodeURIComponent(id))
    .split('{region}').join(encodeURIComponent(region));

  var headers = { Accept: 'application/json' };
  if (process.env.NICK_API_KEY) {
    headers[process.env.NICK_API_KEY_HEADER || 'x-api-key'] = process.env.NICK_API_KEY;
  }

  var ctrl = new AbortController();
  var timeout = setTimeout(function () { ctrl.abort(); }, 7000);

  try {
    var r = await fetch(url, { headers: headers, signal: ctrl.signal });
    if (r.status === 404) {
      return res.status(404).json({ ok: false, error: 'not_found' });
    }
    if (!r.ok) {
      return res.status(502).json({ ok: false, error: 'unavailable' });
    }
    var data = await r.json();
    var nick = clean(findNick(data, 0));
    if (!nick) {
      // o serviço respondeu, mas sem nick: trata como ID não encontrado
      return res.status(404).json({ ok: false, error: 'not_found' });
    }
    res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
    return res.status(200).json({ ok: true, nickname: nick });
  } catch (e) {
    return res.status(502).json({ ok: false, error: 'unavailable' });
  } finally {
    clearTimeout(timeout);
  }
};
